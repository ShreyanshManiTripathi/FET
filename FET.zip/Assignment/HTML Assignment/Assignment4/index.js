
    for(var i=0;i<=300000000;i++){
             var j=i;
    }


postMessage(j);
