var para = document.createElement("p");
document.querySelector("#div1").appendChild(para).innerHTML =
  "This is new para";
