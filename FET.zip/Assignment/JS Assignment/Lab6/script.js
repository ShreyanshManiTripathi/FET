document.querySelector("#link").innerHTML = window.location.href;
document.querySelector("#path").innerHTML = window.location.pathname;
document.querySelector("#protocol").innerHTML = window.location.protocol;
