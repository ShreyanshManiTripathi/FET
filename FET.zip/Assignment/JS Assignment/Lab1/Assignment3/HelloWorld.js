function sayHello()
{
 
    document.write ("“Hello from JavaScript");

}
