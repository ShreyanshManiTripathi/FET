var msg;
msg =
  "<p><code>The script is located in external script file called math.js</code></p>";
function addNumbers(headParam, bodyParam) {
  document.getElementById("text").innerHTML = msg;
  /* display the contents of the variable "msg" */
  /* display the addition of two numbers */
  return headParam + bodyParam;
}
