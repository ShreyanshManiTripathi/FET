// $('header').add('footer').css({'height':'50px','background-color':'red'})$()
// $('section').css({'display':'flex','height':'500px'})
// $('article').css({'width':'900px','background-color':'blue'})
// $('div').add('nav').css({'width':'250px','background-color':'green'})
// ('*').css({'text-align':'centre'})

// $(document).ready(function(){
//     $("button").click(function(){
//         $("p").animate({width:"100%"}).animate({
//             fontSize
//         })
//     })
// })

$(document).ready(
   ()=>{
        $('button#b2').click(()=>{
            $('div').slideToggle(1000);
        })
    

    $('button').click(()=>{
    $('div').fadetoggle(1000);
})

   })

