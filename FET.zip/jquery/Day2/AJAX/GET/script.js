$(document).ready(
    ()=>{
        $("input[type='button']").click(()=>{

            var name=$("input[name='name']").val()
        })
    }
)