var search = document.querySelector('button')


search.addEventListener('click',  ()=> {
  alert("not found")
})