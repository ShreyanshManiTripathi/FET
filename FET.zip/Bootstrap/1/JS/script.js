var myModal = document.getElementById('button')


myModal.addEventListener('click',  ()=> {
  alert("signed in successfully")
})
