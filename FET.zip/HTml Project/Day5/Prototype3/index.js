Employee ={eid:101,ename:'Jim'}
Employee.prototype.workinghr=function(){
    console.log("Actual working hr is 8.5")
    }

    // f(){
    //     console.log("Actual Working is 8.5");
    // }

    e1.workinghr