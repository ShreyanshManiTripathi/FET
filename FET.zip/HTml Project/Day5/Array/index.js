var students=['Rahul','Vivek','Divya','Sumit'] //array



// function iterator(){                  //Iterating the array
// students.forEach(function(element) {
//     console.log(element)
// }, this);

// }

// iterator();

// function addAtRandom (position,element,value1) {  //adding at random position
// students.splice(position,element,value1) 

// console.log(students)
// }

// addAtRandom(2,0,"Shreyansh")

// function removeAtRandom(position,numberOfElements){ //Removing from random position

// students.splice(position,numberOfElements) 

// console.log(students)
// }

// removeAtRandom(2,2)

