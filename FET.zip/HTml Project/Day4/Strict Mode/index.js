"use strict";
function x(p1,p2){};
delete x;