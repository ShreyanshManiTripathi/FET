


function finalAmount (value,discount)
{

     var amount=value- (value*discount/100)

}




var value=prompt("Enter The amount:")



var discount=prompt("Enter The discount %")




     var amount=value- (value*discount/100)


alert("your bill is" + amount)

