document.querySelector('body').innerText="Welcome To Javasript";

{var ages =42;}

let age =42

console.log(age);
console.log(ages);

for(index=1;index<5;index++)
    {console.log(index)}


var fruits=["Apple","Mango"]

var first=fruits[0]


var last=fruits[fruits.length-1]

fruits.push('leechi')
// var newlength=fruits.push("orange")
// console.log(fruits)
// var lastt=fruits.pop()

// console.log(fruits)

console.log(fruits)
 var pos=fruits.indexOf("Apple")

console.log(pos)

var removedItem=fruits.splice(pos,1)

console.log(removedItem)